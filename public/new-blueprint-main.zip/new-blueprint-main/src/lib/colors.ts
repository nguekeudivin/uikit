// Associate any value to a particular.
// It's like text => color translation.

const colors: Record<string, string> = {
  "success": ""
};

export default colors;
