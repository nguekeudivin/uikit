export default function EcommercePage() {
  return <h1> E-commerce </h1>;
}
